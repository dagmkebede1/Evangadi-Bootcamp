// Question 1
//   Add a list of radio buttons on the page containing different color options. When a user clicks on one of them, the background of the page should change to the selected color.
//     - Two of the buttons that say "Night mode" and "Sunny Mode". When night mode is chosen, the background should change to black and the texts should change to white. When Sunny mode is chosen, the background should change to light blue and texts should be in black.



// Question 2

// create a two functions for each buttons to increase and decrease the value in the middle
// note: the number shouldn't go below 0 and above 20



// Question 3

// Validate the Login form

// Change the background of the input boxes to pink if a user tries to submit empty form for each input box and if all the values are all fulfilled show a message on alert box saying "Form submitted"
